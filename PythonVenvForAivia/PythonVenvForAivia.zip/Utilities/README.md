# Utilities

- CalculateIntersectionOverUnion.py
- ConvertMultipleExcelTablesToSingle.py
- ConvertSpreadsheetToSingleTab.py
- DICOMStackToTIFF.py: not included in the PythonVenvForAivia pack
- ExtractDeepLearningInfoInLogFile: version which is based on wxPython for UI
- Heatmap_FromExcelTable.py
- InspectLineIntersections.py: not included in the PythonVenvForAivia pack
- ProcessMultipleExcelTables_FromAivia.py
- ReadTiffTags.py
- RunExternalProgram_example.py: 
- SeabornToAiviaColoring.py: not included in the PythonVenvForAivia pack
- ShowPythonLogMessages.py: not included in the PythonVenvForAivia pack
