These color maps can be loaded directly in Aivia:
+ Right-click on the channel to color-code
+ Go to "Advanced Coloring" > "Load Coloring"

During your Aivia session, the loaded color maps are available in "Advanced Coloring" > "Custom Mappings"
