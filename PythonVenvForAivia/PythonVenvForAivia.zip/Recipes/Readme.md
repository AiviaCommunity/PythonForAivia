# Python recipes

Information for each recipe can be found in each file, in the header part. 

To dowwnload one recipe, click on its name, then right-click on "Raw" button on the top-right > Save Link As...

![](/DRVisionFiles/Snapshots/DownloadPyFile.jpg)
